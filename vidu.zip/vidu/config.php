<?php
    $conn= mysqli_connect("localhost","root","","vidu");
    mysqli_set_charset($conn,"utf8");

?>